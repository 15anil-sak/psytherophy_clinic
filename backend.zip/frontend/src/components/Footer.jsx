import React from 'react';

const Footer = () => {
  return (
    <footer>
      <p>Copyright &copy; 2025 Physiotherapy Clinic</p>
    </footer>
  );
};

export default Footer;
