import React, { useState, useEffect } from 'react';
import { fetchAppointments } from '../services/api';

const AppointmentsPage = () => {
  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
    const getAppointments = async () => {
      try {
        const { data } = await fetchAppointments();
        setAppointments(data);
      } catch (error) {
        console.error('Failed to fetch appointments:', error);
      }
    };
    getAppointments();
  }, []);

  return (
    <div>
      <h1>Your Appointments</h1>
      <ul>
        {appointments.map((appointment) => (
          <li key={appointment.id}>
            <h2>{appointment.service_name}</h2>
            <p>Patient: {appointment.patient_name}</p>
            <p>Date: {new Date(appointment.appointment_date).toLocaleDateString()}</p>
            <p>Status: {appointment.status}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AppointmentsPage;