import React from 'react';

const HomePage = () => {
  return (
    <div>
      <h1>Welcome to the Physiotherapy Clinic</h1>
      <p>Your health is our priority.</p>
    </div>
  );
};

export default HomePage;
